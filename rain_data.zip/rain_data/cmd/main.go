package main

import (
	"os"
	"os/signal"
	"time"

	log "github.com/sirupsen/logrus"
	"meihuan.com/mentha/config"
	"meihuan.com/mentha/internal/app/calculate"
	"meihuan.com/mentha/internal/app/monitor"
	"meihuan.com/mentha/internal/app/mq"
)

var mnLog = log.Fields{"product": "凉山电力", "program": "weather", "moudle": "main"}

func main() {
	start()

	c := make(chan os.Signal)
	signal.Notify(c, os.Interrupt)
	s := <-c
	log.WithFields(mnLog).Infoln("程序收到中断信号", s)
	time.Sleep(time.Millisecond)
}

func start() {
	if config.Wth.Enable {
		go calculate.Start()
		go monitor.Start()
	}
	if config.Messageque.Enable {
		go mq.Monitor()
	}
}
