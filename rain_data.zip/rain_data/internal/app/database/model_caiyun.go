package database

// Caiyun 彩云气象数据接口
type Caiyun struct {
	Status     string    `json:"status"`      // 数据返回状态
	APIVersion string    `json:"api_version"` // 版本号
	APIStatus  string    `json:"api_status"`  // 版本号状态
	Lang       string    `json:"lang"`        // 语言
	Unit       string    `json:"unit"`        // 单位制
	TZshift    uint32    `json:"tzshift"`     // 时区的偏移秒数，如东八区就是 28800 (8*60*60)秒
	TimeZone   string    `json:"timezone"`    // 时区（eg. "Asia/Chongqing"）
	ServerTime int64     `json:"server_time"` // 服务器本次返回的utc时间戳
	Location   []float32 `json:"location"`    // 纬经度 （eg. [25.1552, 121.6544]）
	Result     ResultAPI `json:"result"`      // 气象信息
}

// ResultAPI -
type ResultAPI struct {
	Realtime         CYRealtimeAPI `json:"realtime,omitempty"` // 实况级模块
	Minutely         CYMinutelyAPI `json:"minutely,omitempty"` // 逐分钟级模块
	Hourly           CYHourlyAPI   `json:"hourly,omitempty"`   // 逐小时级模块
	Daily            CYDailyAPI    `json:"daily,omitempty"`    // 逐日级模块
	Alert            CYAlertAPI    `json:"alert,omitempty"`    // 预警模块
	Primary          int32         `json:"primary"`            // 预留字段，目前未使用
	ForecastKeypoint string        `json:"forecast_keypoint"`  // 语言描述预报关键信息 （"空气不太好，在室内休息休息吧"）
}

// CYRealtimeAPI 实况气象信息 ===============================================
type CYRealtimeAPI struct {
	Status              string            `json:"status"`               // 实况模块返回状态
	Temperature         float32           `json:"temperature"`          // 温度
	ApparentTemperature float32           `json:"apparent_temperature"` // 表面温度
	Humidity            float32           `json:"humidity"`             // 相对湿度
	Cloudrate           float32           `json:"cloudrate"`            // 云量
	Skycon              string            `json:"skycon"`               // 主要天气现象
	Visibility          float32           `json:"visibility"`           // 能见度
	Dswrf               float32           `json:"dswrf"`                // 向下短波辐射通量
	Pressure            float32           `json:"pressure"`             // 气压
	Wind                WindInfo          `json:"wind"`                 // 风
	Precipitation       PrecipitationInfo `json:"precipitation"`        // 降水预测
	Airquality          AirqualityInfo    `json:"air_quality"`          // 空气质量
	LifeIndex           LifeindexInfo     `json:"life_index"`           // 生活指数
}

// WindInfo -
type WindInfo struct {
	Speed     float32 `json:"speed"`     // 风速，米制下是公里每小时
	Direction float32 `json:"direction"` // 风向，单位是度。正北方向为0度，顺时针增加到360度
}

// LocalInfo 本地降水信息
type LocalInfo struct {
	Status     string  `json:"status"`
	Datasource string  `json:"datasource"` // 本地降水观测的数据源（radar，GFS）
	Intensity  float32 `json:"intensity"`  // 本地降水强度（单位为雷达降水强度: 0~1）
}

// NearestInfo 最近降水带信息
type NearestInfo struct {
	Status    string  `json:"status"`
	Distance  float32 `json:"distance"`  // 最近的降水带距离
	Intensity float32 `json:"intensity"` // 最近的降水带降水强度（单位为雷达降水强度: 0~1）
}

// PrecipitationInfo 降水预测信息
type PrecipitationInfo struct {
	Local   LocalInfo   `json:"local"`
	Nearest NearestInfo `json:"nearest"`
}

// AirqualityInfo 空气质量信息
type AirqualityInfo struct {
	Pm25        float32         `json:"pm25"` // pm25，质量浓度值
	Pm10        float32         `json:"pm10"` // pm10，质量浓度值
	O3          float32         `json:"o3"`   // 臭氧，质量浓度值
	So2         float32         `json:"so2"`  // 二氧化硫，质量浓度值
	No2         float32         `json:"no2"`  // 二氧化氮，质量浓度值
	Co          float32         `json:"co"`   // 一氧化碳，质量浓度值
	Aqi         AqiInfo         `json:"aqi"`  // aqi
	Description DescriptionInfo `json:"description"`
}

// AqiInfo -
type AqiInfo struct {
	Chn float32 `json:"chn"` // AQI（中国标准）
	Usa float32 `json:"usa"` // AQI（美国标准）
}

// DescriptionInfo -
type DescriptionInfo struct {
	Chn string `json:"chn"` // 中文描述
	Usa string `json:"usa"` // 英文描述
}

// LifeindexInfo 生活指数
type LifeindexInfo struct {
	Ultraviolet LifeindexInfo2 `json:"ultraviolet"` // 紫外线
	Comfort     LifeindexInfo2 `json:"comfort"`     // 舒适度
}

// LifeindexInfo2 -
type LifeindexInfo2 struct {
	Index float32 `json:"index"` //等级
	Desc  string  `json:"desc"`  //描述
}

// CYMinutelyAPI 逐分钟级预报信息 ===============================================
type CYMinutelyAPI struct {
	Status          string    `json:"status"`           // 分钟级模块返回状态
	Description     string    `json:"description"`      // 天气预报，自然语言描述
	Datasource      string    `json:"datasource"`       // 数据来源
	Precipitation2h []float32 `json:"precipitation_2h"` // 未来2小时，逐分钟，雷达降水强度预报
	Precipitation   []float32 `json:"precipitation"`    // 未来1小时，逐分钟，雷达降水强度预报
	Probability     []float32 `json:"probability"`      // 未来2小时，逐半小时，雷达降水概率预报
}

// CYHourlyAPI 逐小时级预报信息 ===============================================
type CYHourlyAPI struct {
	Status        string               `json:"status"`        // 小时级模块返回状态
	Description   string               `json:"description"`   // 天气预报，自然语言描述
	Precipitation []HourlyInfo         `json:"precipitation"` // 本地降水强度
	Temperature   []HourlyInfo         `json:"temperature"`   // 温度
	Humidity      []HourlyInfo         `json:"humidity"`      // 相对湿度
	Cloudrate     []HourlyInfo         `json:"cloudrate"`     // 云量
	Pressure      []HourlyInfo         `json:"pressure"`      // 气压
	Visibility    []HourlyInfo         `json:"visibility"`    // 能见度
	Dswrf         []HourlyInfo         `json:"dswrf"`         // 短波辐射
	Wind          []HourlyWindInfo     `json:"wind"`          // 逐小时风力信息
	Skycon        []HourlySkyconInfo   `json:"skycon"`        // 逐小时天气现象
	Airquality    HourlyAirqualityInfo `json:"air_quality"`   // 逐小时天气质量
}

// HourlyInfo -
type HourlyInfo struct {
	Datetime string  `json:"datetime"` // 时间（2020-03-19T10:00+08:00）
	Value    float32 `json:"value"`    // 强度
}

// HourlyWindInfo -
type HourlyWindInfo struct {
	Datetime  string  `json:"datetime"`  // 时间（2020-03-19T10:00+08:00）
	Speed     float32 `json:"speed"`     // 风速，米制下是公里每小时
	Direction float32 `json:"direction"` // 风向，单位是度。正北方向为0度，顺时针增加到360度
}

// HourlySkyconInfo -
type HourlySkyconInfo struct {
	Datetime string `json:"datetime"` // 时间（2020-03-19T10:00+08:00）
	Value    string `json:"value"`    // 天气现象
}

// HourlyAirqualityInfo -
type HourlyAirqualityInfo struct {
	Aqi  []HourlyAqiInfo  `json:"aqi"`  // 逐小时AQI
	Pm25 []HourlyPm25Info `json:"pm25"` // 逐小时pm25
}

// HourlyAqiInfo -
type HourlyAqiInfo struct {
	Datetime string  `json:"datetime"` // 时间（2020-03-19T10:00+08:00）
	Value    AqiInfo `json:"value"`    // AQI
}

// HourlyPm25Info -
type HourlyPm25Info struct {
	Datetime string `json:"datetime"` // 时间（2020-03-19T10:00+08:00）
	Value    int32  `json:"value"`    // pm25
}

// CYDailyAPI 逐天级预报信息 ===============================================
type CYDailyAPI struct {
	Status        string              `json:"status"`         // 天级模块返回状态
	Astro         []DailyAstroInfo    `json:"astro"`          // 日出日落信息
	Precipitation []DailyInfo         `json:"precipitation"`  // 本地降水强度(单位见表格)
	Temperature   []DailyInfo         `json:"temperature"`    // 温度
	Humidity      []DailyInfo         `json:"humidity"`       // 相对湿度
	Cloudrate     []DailyInfo         `json:"cloudrate"`      // 云量
	Pressure      []DailyInfo         `json:"pressure"`       // 气压
	Visibility    []DailyInfo         `json:"visibility"`     // 能见度
	Dswrf         []DailyInfo         `json:"dswrf"`          // 短波辐射
	Skycon        []DailySkyconInfo   `json:"skycon"`         // 全天，主要天气现象
	Skycon08h20h  []DailySkyconInfo   `json:"skycon_08h_20h"` // 白天，主要天气现象
	Skycon20h32h  []DailySkyconInfo   `json:"skycon_20h_32h"` // 夜晚，主要天气现象
	Wind          []DailyWindInfo     `json:"wind"`           // 风速
	Lifeindex     DailyLifeindexInfo  `json:"life_index"`     // 逐天生活指数
	Airquality    DailyAirqualityInfo `json:"air_quality"`    // 逐天空气质量
}

// DailyAstroInfo -
type DailyAstroInfo struct {
	Date    string               `json:"date"`    // 时间（2020-03-19T10:00+08:00）
	Sunrise DailySunRaiseSetTime `json:"sunrise"` // 日出
	Sunset  DailySunRaiseSetTime `json:"sunset"`  // 日落
}

// DailySunRaiseSetTime -
type DailySunRaiseSetTime struct {
	Time string `json:"time"` // 时间(北京时间，tzshift不作用在这个变量)
}

// DailyInfo -
type DailyInfo struct {
	Date string  `json:"date"` // 时间（2020-03-19T00:00+08:00）
	Max  float32 `json:"max"`  // 最大值
	Min  float32 `json:"min"`  // 最小值
	Avg  float32 `json:"avg"`  // 平均值
}

// DailySkyconInfo -
type DailySkyconInfo struct {
	Date  string `json:"date"`  // 时间（2020-03-19T00:00+08:00）
	Value string `json:"value"` // 天气现象
}

// DailyWindInfo -
type DailyWindInfo struct {
	Date string   `json:"date"` // 时间（2020-03-19T00:00+08:00）
	Max  WindInfo `json:"max"`  // 最大风速
	Min  WindInfo `json:"min"`  // 平均风速
	Avg  WindInfo `json:"avg"`  // 最小风速
}

// DailyAirqualityInfo -
type DailyAirqualityInfo struct {
	Aqi  []DailyAqiInfo  `json:"aqi"`
	Pm25 []DailyPm25Info `json:"pm25"`
}

// DailyAqiInfo -
type DailyAqiInfo struct {
	Date string  `json:"date"` // 时间（2020-03-19T00:00+08:00）
	Max  AqiInfo `json:"max"`
	Min  AqiInfo `json:"min"`
	Avg  AqiInfo `json:"avg"`
}

// DailyPm25Info -
type DailyPm25Info struct {
	Date string  `json:"date"` // 时间（2020-03-19T00:00+08:00）
	Max  int32   `json:"max"`  // 最大值
	Min  int32   `json:"min"`  // 最小值
	Avg  float32 `json:"avg"`  // 平均值
}

// DailyLifeindexInfo -
type DailyLifeindexInfo struct {
	Ultraviolet []DailyLifeindex `json:"ultraviolet"`
	CarWashing  []DailyLifeindex `json:"carWashing"`
	Dressing    []DailyLifeindex `json:"dressing"`
	Comfort     []DailyLifeindex `json:"comfort"`
	ColdRisk    []DailyLifeindex `json:"coldRisk"`
}

// DailyLifeindex -
type DailyLifeindex struct {
	Date  string `json:"date"`  // 时间（2020-03-19T00:00+08:00）
	Index string `json:"index"` // 级别
	Desc  string `json:"desc"`  // 描述
}

// CYAlertAPI 预警信息 ===========================================================
type CYAlertAPI struct {
	Status  string      `json:"status"`  // 预警模块返回状态
	Content []AlertInfo `json:"content"` // 预警内容（可能同时存在多个预警信息，比如暴风、暴雨, 可能不存在预警信息，此时content内容为空[]）
}

// AlertInfo -
type AlertInfo struct {
	RequestStatus string    `json:"request_status"` // 请求状态 （"ok"）
	Status        string    `json:"status"`         // 预警状态 ("预警中")
	Province      string    `json:"province"`       // 省份，（"河南省"）
	City          string    `json:"city"`           // 城市 （"南阳市"）
	County        string    `json:"county"`         // 县 （"无"）
	Location      string    `json:"location"`       // 地址 （"河南省南阳市"）
	RegionID      string    `json:"regionId"`       // 区域id （"unknown"）
	Latlon        []float32 `json:"latlon"`         // 纬经度 （[32.990833,112.528321]）
	Adcode        string    `json:"adcode"`         // 行政区编码 （"411300"）
	Pubtimestamp  float64   `json:"pubtimestamp"`   // 预警发布时间戳（1584584323.0）
	AlertID       string    `json:"alertId"`        // 预警id （"41130041600000_20200319101745"）
	Source        string    `json:"source"`         // 预警发布来源 （"国家预警信息发布中心"）
	Code          string    `json:"code"`           // 预警类型code，code编码规则见官网表格（"0501"）
	Title         string    `json:"title"`          // 预警title （"南阳市气象局发布大风蓝色预警[IV级/一般]"）
	Description   string    `json:"description"`    // 预警详细描述 （"南阳市气象台2020年3月19日10时18分继续发布大风蓝色预警信号：预计未来24小时内，南阳市大部分地区仍将受大风影响，平均风力4-5级，局地阵风7级以上，请注意防范。"）
}
