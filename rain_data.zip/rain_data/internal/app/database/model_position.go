package database

import log "meihuan.com/mentha/internal/app/logger"

// AnchorPoint -
type AnchorPoint struct {
	ID  int64   `json:"id" xorm:"id pk autoincr"`
	Lon float32 `json:"lon" xorm:"lon"` // 锚点经度
	Lat float32 `json:"lat" xorm:"lat"` // 锚点纬度
}

// RainCompare -
type RainCompare struct {
	ID         int64     `json:"id" xorm:"id pk autoincr"`
	PointID    int64     `json:"point_id" xorm:"point_id"`
	ReatimeCY  float32   `json:"realtimeCY" xorm:"realtime_cy"` // 实况降雨量-彩云
	ReatimeXJ  float32   `json:"realtimeXJ" xorm:"realtime_xj"` // 实况降雨量-象辑
	MinutelyCY []float32 `json:"minutelyCY" xorm:"minutely_cy"` // 未来两小时每分钟降雨预测-彩云
	MinutelyXJ []float32 `json:"minutelyXJ" xorm:"minutely_xj"` // 未来两小时每分钟降雨预测-象辑
	HourlyCY   []float32 `json:"hourlyCY" xorm:"hourly_cy"`     // 未来72小时每小时降雨预测-彩云
	HourlyXJ   []float32 `json:"hourlyXJ" xorm:"hourly_xj"`     // 未来72小时每小时降雨预测-象辑
}
const (
	LEFTLON  = 99.0
	RIGHTLON = 108.0
	BTMLAT   = 26.0
	TOPLAT   = 34.0
)
//在包含四川辖区的一个矩形内生成大约500个经纬度点
func GenPositions() (err error){
	var longitude float32
	var latitude float32
	for longitude = LEFTLON; longitude < RIGHTLON; longitude=+0.375 {
		for latitude = BTMLAT;latitude < TOPLAT; latitude+=0.38{
			err := Addpositions(longitude, latitude)
			if err!=nil{
				log.Err(err).Msg("插入失败")
				return err
			}
		}
	}
	return
}
func Addpositions(lon float32,lat float32) (err error){
	point := &AnchorPoint{
		Lon: lon,
		Lat: lat,
	}
	engine := GetEngine()
	_, err = engine.InsertOne(point)
	if err!=nil{
		log.Err(err).Msg("插入经纬点失败")
	}
	return err
}
func Getpositions()(err error){
	engine := GetEngine()
	points := make([]*AnchorPoint, 0)
	err = engine.Table(&AnchorPoint{}).Find(&points)
	if err!=nil{
		log.Err(err).Msg("查询经纬点失败")
	}
	return err
}