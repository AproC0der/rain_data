package database

import (
	"fmt"
	"testing"
)

func TestDB(t *testing.T) {
	Gen()
}
func Gen() {
	var longitude float32
	var latitude float32
	for longitude = LEFTLON; longitude < RIGHTLON; longitude = +0.375 {
		for latitude = BTMLAT; latitude < TOPLAT; latitude += 0.38 {
			fmt.Println(longitude, latitude)
		}
	}
}
