package database

// Weather 通用气象数据接口
type Weather struct {
	Caiyun  *Caiyun  `json:"caiyun"`
	Xiangji *Xiangji `json:"xiangji"`
}




