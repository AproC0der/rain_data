package database

import (
	"encoding/json"
	"errors"
	log "github.com/sirupsen/logrus"
	"io/ioutil"
	"net/http"
	"time"
)

var mnLog = log.Fields{"program": "rain_data", "moudle": "monitor"}

// Get 根据URL、气象厂商、气象目标获取气象信息
// url 彩云api
func (weather *Weather) GetCaiyun(URL string) (err error) {
	resp, err := http.Get(URL)
	if err != nil {
		log.Errorln("获取彩云天气信息http请求失败", err, URL)
		return err
	}
	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Errorln("读取彩云气象http请求的响应失败", err, URL)
		return err
	}
	if weather == nil {
		log.Errorln("weather为空")
		return
	}
	weather.Caiyun=new(Caiyun)
	err = json.Unmarshal(data, weather.Caiyun)
	if err == nil && weather.Caiyun.Status != "ok" {
		err = errors.New("获取彩云通用数据失败")
	}
	var i int
	for i = 0; i < 5 && (err != nil || (err == nil && weather.Caiyun.Status != "ok")); i++ {
		time.Sleep(time.Duration(i) * time.Millisecond)
		err = weather.GetCaiyun(URL)
	}
	if i == 5 {
		log.WithFields(mnLog).Errorln("获取气象信息失败", err)
		return
	}
	return
}

// Get 根据URL、气象厂商、气象目标获取气象信息
// url 象辑api
func (weather *Weather) GetXiangji(minutelyURL string, realtimeURL string, hourlyURL string) (err error) {
	if weather.Xiangji == nil {
		weather.Xiangji = new(Xiangji)
	}
	//获取实况信息,失败重试5次
	err = GetRealtime(weather, realtimeURL)
	for i := 0; i < 5 && (err != nil || (err == nil && weather.Xiangji.Realtime.Status != 0)); i++ {
		time.Sleep(time.Duration(i) * time.Millisecond)
		err = GetRealtime(weather, realtimeURL)
	}
	//获取短临信息
	err = GetMinutely(weather, minutelyURL)
	for i := 0; i < 5 && (err != nil || (err == nil && weather.Xiangji.Minutely.Status != 0)); i++ {
		time.Sleep(time.Duration(i) * time.Millisecond)
		err = GetMinutely(weather, minutelyURL)
	}
	//获取小时信息
	err = GetHourly(weather, hourlyURL)
	for i := 0; i < 5 && (err != nil || (err == nil && weather.Xiangji.Hourly.Status != 0)); i++ {
		time.Sleep(time.Duration(i) * time.Millisecond)
		err = GetHourly(weather, hourlyURL)
	}
	return err
}
func GetRealtime(weather *Weather, realtimeURL string) (err error) {
	resp, err := http.Get(realtimeURL)
	if err != nil {
		log.Errorln("获取象辑天气http请求失败", err, realtimeURL)
		return err
	}
	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Errorln("读取象辑气象http请求的响应失败", err, realtimeURL)
		return err
	}
	weather.Xiangji.Realtime = new(XJRealtimeAPI)
	err = json.Unmarshal(data, weather.Xiangji.Realtime)
	if err == nil && weather.Xiangji.Realtime.Status != 0 {
		err = errors.New("获取象辑实况数据失败")
	}
	return err
}
func GetMinutely(weather *Weather, minutelyURL string) (err error) {
	resp, err := http.Get(minutelyURL)
	if err != nil {
		log.Errorln("获取象辑天气http请求失败", err, minutelyURL)
		return err
	}
	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Errorln("读取象辑气象http请求的响应失败", err, minutelyURL)
		return err
	}
	weather.Xiangji.Minutely = new(XJMinutelyAPI)
	err = json.Unmarshal(data, weather.Xiangji.Minutely)
	if err == nil && weather.Xiangji.Minutely.Status != 0 {
		err = errors.New("获取象辑实况数据失败")
	}
	return err
}
func GetHourly(weather *Weather, hourlyURL string) (err error) {
	resp, err := http.Get(hourlyURL)
	if err != nil {
		log.Errorln("获取象辑天气http请求失败", err, hourlyURL)
		return err
	}
	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Errorln("读取象辑气象http请求的响应失败", err, hourlyURL)
		return err
	}
	weather.Xiangji.Hourly = new(XJHourlyAPI)
	err = json.Unmarshal(data, weather.Xiangji.Hourly)
	if err == nil && weather.Xiangji.Hourly.Status != 0 {
		err = errors.New("获取象辑实况数据失败")
	}
	return err
}
