package database

// Xiangji 象辑通用接口
type Xiangji struct {
	Realtime *XJRealtimeAPI `json:"realtime"`
	Minutely *XJMinutelyAPI `json:"minutely"`
	Hourly   *XJHourlyAPI   `json:"hourly"`
	Daily    *XJDailyAPI    `json:"daily"`
}

// XJMinutelyAPI 象辑短临
type XJMinutelyAPI struct {
	Status  int32   `json:"status"`
	Result  mresult `json:"result"`
	Message string  `json:"message"`
}

// XJRealtimeAPI 象辑实况
type XJRealtimeAPI struct {
	Status  int32   `json:"status"`
	Result  rresult `json:"result"`
	Message string  `json:"message"`
}

// XJHourlyAPI 象辑逐小时
type XJHourlyAPI struct {
	Status  int32   `json:"status"`
	Result  hresult `json:"result"`
	Message string  `json:"message"`
}

// XJDailyAPI 象辑逐天
type XJDailyAPI struct {
	Status  int32   `json:"status"`
	Result  dresult `json:"result"`
	Message string  `json:"message"`
}

//短临结果
type mresult struct {
	StartTime string    `json:"startTime"` // 预报开始时间，未来两小时无降雨时为空
	EndTime   string    `json:"endTime"`   // 预报结束时间，未来两小时无降雨时为空
	Series    []float32 `json:"series"`    // 逐分钟雨强预测，单位mm/hr，未来两小时无降雨时为空
	Text      string    `json:"text"`      // 实时天气现象
	Code      string    `json:"code"`      // 实时天气编码
	Msg       string    `json:"msg"`       // 短临预报描述
}

//实况结果
type rresult struct {
	Realtime   realtime `json:"realtime"`
	LastUpdate string   `json:"last_update"`
}
type realtime struct {
	Text        string  `json:"text"`       // 天气现象， eg. "多云"
	Code        string  `json:"code"`       // 天气现象编码，eg. "01"
	Temperature float32 `json:"temp"`       // 气温
	FeelsLike   int32   `json:"feels_like"` // 体感温度
	Humidity    int32   `json:"rh"`         // 相对湿度 [0,100]
	WindClass   string  `json:"wind_class"` // 风级 eg."2级"
	WindSpeed   float32 `json:"wind_speed"` // 风速，m/s
	WindAngle   int32   `json:"wind_angle"` // 风向角，[0,360]
	WindDir     string  `json:"wind_dir"`   // 风向
	RainPrec    float32 `json:"prec"`       // 过去1小时降水量，单位毫米(mm)
	Clouds      int32   `json:"clouds"`     // 云量, [0,100]
	Vis         int32   `json:"vis"`        // 能见度， 单位（米）
	Pressure    int32   `json:"pressure"`   // 气压，单位（百帕）
	Dew         int32   `json:"dew"`        // 露点温度
}

//逐小时结果
type hresult struct {
	Hourly     []hourly `json:"hourly_fcsts"`
	LastUpdate string   `json:"last_update"`
}
type hourly struct {
	Text        string  `json:"text"`       // 天气现象
	Code        string  `json:"code"`       // 天气现象代码
	Temperature int32   `json:"temp_fc"`    // 温度
	WindClass   string  `json:"wind_class"` // 风级
	WindDir     string  `json:"wind_dir"`   // 风向
	WindSpeed   float32 `json:"wind_speed"` // 风速（m/s）
	WindAngle   float32 `json:"wind_angle"` // 风向角
	Humidity    int32   `json:"rh"`         // 相对湿度 [0,100]
	RainPrec    float32 `json:"prec"`       // 降水量，单位（毫米mm）
	Pressure    int32   `json:"pressure"`   // 气压，单位百帕
	Clouds      int32   `json:"clouds"`     // 云量
	FeelsLike   int32   `json:"feels_like"` // 体感温度
	DataTime    string  `json:"data_time"`  // 预报时次，当地时间
}

//逐日结果
type dresult struct {
	Daily      []daily `json:"daily_fcsts"`
	LastUpdate string  `json:"last_update"`
}
type daily struct {
	TextDay   string `json:"text_day"`   //日间天气现象
	CodeDat   string `json:"code_day"`   //日间天气现象代码
	TextNight string `json:"text_night"` //夜间天气现象
	CodeBight string `json:"code_night"` //夜间天气现象代码
	High      int32  `json:"high"`       //最高温
	Low       int32  `json:"low"`        //最低温
	WcDay     string `json:"wc_day"`     //日间风级
	WdDay     string `json:"wd_day"`     //日间风向
	WcNight   string `json:"wc_night"`   //夜间风级
	WdNight   string `json:"wd_night"`   //夜间风向
	Date      string `json:"date"`       //日期
	Week      string `json:"week"`       //星期
}


