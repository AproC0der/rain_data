package database

import (
	"github.com/go-xorm/xorm"
	_ "github.com/lib/pq" // postgres driver
	log "meihuan.com/mentha/internal/app/logger"
	"xorm.io/core"
)

//NewDBEngine --
var engine *xorm.Engine

// NewDBEngine -
func NewDBEngine(driver, source string) (err error) {
	engine, err = xorm.NewEngine(driver, source)
	if err != nil {
		log.Err(err).Msg("Failed to connect database")
		panic("Failed to connect database")
	}
	if writer := log.GetWriter(); writer != nil {
		engine.SetLogger(xorm.NewSimpleLogger(writer))
	}
	engine.ShowSQL(true)
	err = engine.Ping()
	if err != nil {
		log.Err(err).Msg("Failed to ping database")
		panic("Failed to connect database")
	}
	engine.SetMapper(core.GonicMapper{})
	// setLogger()
	err = engine.Sync2(new(AnchorPoint),new(RainCompare))
	if err != nil {
		log.Err(err).Msg("sync database")
		panic("Failed to sync to database")
	}
	return
}

//GetEngine --
func GetEngine() *xorm.Engine {
	return engine
}