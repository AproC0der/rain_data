package database

import (
	"encoding/json"
	"io/ioutil"
	"meihuan.com/mentha/config"
	"net/http"
	"strconv"
	"testing"
)

const (
	LONGITUDE = 104.06
	LATITUDE  = 30.67
)

func TestCaiyun(t *testing.T) {
	targetLoc := strconv.FormatFloat(LONGITUDE, 'f', 6, 64) + "," + strconv.FormatFloat(LATITUDE, 'f', 6, 64)
	url := config.Caiyun.Host + "/" + config.Caiyun.Version + "/" + config.Caiyun.Token + "/" + targetLoc + "/weather.json" + "?" + "unit=" + config.Caiyun.Unit + "&alert=" + config.Caiyun.Alert + "&hourlysteps=72&dailysteps=15"
	resp, err := http.Get(url)
	if err != nil {
		t.Errorf("%s", err)
	}
	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		t.Errorf("%s", err)
	}
	weather := &Weather{}
	weather.Caiyun = new(Caiyun)
	err = json.Unmarshal(data, weather.Caiyun)
	if err != nil || weather.Caiyun.Status != "ok" {
		t.Errorf("%s", err)
	}
}
func TestXiangji(t *testing.T) {
	targetLoc := strconv.FormatFloat(LONGITUDE, 'f', 6, 64) + "," + strconv.FormatFloat(LATITUDE, 'f', 6, 64)
	hourlyURL := config.Xiangji.Host + "/weather/" + config.Xiangji.Version + "/hour?lonlat=" + targetLoc + "&hours=72" + "&key=" + config.Xiangji.Token + "&output_type=" + config.Xiangji.Outtype // 小时级接口
	minutelyURL := config.Xiangji.Host + "/high_res/" + config.Xiangji.Version + "/nowcasting?lonlat=" + targetLoc + "&key=" + config.Xiangji.Token + "&output_type=" + config.Xiangji.Outtype      // 短临接口
	realtimeURL := config.Xiangji.Host + "/weather/" + config.Xiangji.Version + "/now?lonlat=" + targetLoc + "&key=" + config.Xiangji.Token + "&output_type=" + config.Xiangji.Outtype              // 实况接口
	w := &Weather{}
	err := w.GetXiangji(minutelyURL, realtimeURL, hourlyURL)
	if err!=nil{
		t.Errorf("%s", err)
	}
}
