package monitor

import (
	"fmt"
	log "github.com/sirupsen/logrus"
	"meihuan.com/mentha/config"
	"meihuan.com/mentha/internal/app/database"
	"strconv"
)

func Onrain(longitude float32, latitude float32) {
	targetLoc := strconv.FormatFloat(float64(longitude), 'f', 6, 64) + "," + strconv.FormatFloat(float64(latitude), 'f', 6, 64)
	url := config.Caiyun.Host + "/" + config.Caiyun.Version + "/" + config.Caiyun.Token + "/" + targetLoc + "/weather.json" + "?" + "unit=" + config.Caiyun.Unit + "&alert=" + config.Caiyun.Alert + "&hourlysteps=72&dailysteps=15"
	minutelyURL := config.Xiangji.Host + "/high_res/" + config.Xiangji.Version + "/nowcasting?lonlat=" + targetLoc + "&key=" + config.Xiangji.Token + "&output_type=" + config.Xiangji.Outtype      // 短临接口
	realtimeURL := config.Xiangji.Host + "/weather/" + config.Xiangji.Version + "/now?lonlat=" + targetLoc + "&key=" + config.Xiangji.Token + "&output_type=" + config.Xiangji.Outtype              // 实况接口
	hourlyURL := config.Xiangji.Host + "/weather/" + config.Xiangji.Version + "/hour?lonlat=" + targetLoc + "&hours=72" + "&key=" + config.Xiangji.Token + "&output_type=" + config.Xiangji.Outtype // 小时级接口
	weather := new(database.Weather)
	err := weather.GetCaiyun(url)
	if err!=nil{
		log.Errorln("重试5次后仍然失败",err)
		return
	}
	err = weather.GetXiangji(minutelyURL, realtimeURL, hourlyURL)
	if err!=nil{
		log.Errorln("重试5次后仍然失败",err)
		return
	}
	hourlyCY := make([]float32, 0)
	hourlycy := weather.Caiyun.Result.Hourly.Precipitation
	for _,v:=range hourlycy{
		hourlyCY = append(hourlyCY, v.Value)
	}
	hourlyXJ:=make([]float32,0)
	hourlyxj:= weather.Xiangji.Hourly.Result.Hourly
	for _,v:=range hourlyxj{
		hourlyXJ = append(hourlyCY, v.RainPrec)
	}
	rain := &database.RainCompare{


		ReatimeCY: weather.Caiyun.Result.Minutely.Precipitation2h[0],
		ReatimeXJ: weather.Xiangji.Realtime.Result.Realtime.RainPrec,
		MinutelyCY: weather.Caiyun.Result.Minutely.Precipitation2h,
		MinutelyXJ: weather.Xiangji.Minutely.Result.Series,
		HourlyCY: hourlyCY,
		HourlyXJ: hourlyXJ,
	}
	fmt.Println(rain)

}