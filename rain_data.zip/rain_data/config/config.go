package config

import (
	"time"

	"github.com/koding/multiconfig"
	log "github.com/sirupsen/logrus"
)

// 所有配置
var conf configure

// Caiyun 彩云配置
var Caiyun *caiyun

// Xiangji 象辑配置
var Xiangji *xiangji

// Wth 提供商
var Wth *wth

// Database 数据库配置
var Database *database

// Messageque nats消息队列配置
var Messageque *messagequeue

type messagequeue struct {
	Enable bool
	Host   string
}

type caiyun struct {
	Host    string
	Version string
	Token   string
	Unit    string
	Alert   string
}

type xiangji struct {
	Host    string
	Version string
	Token   string
	Outtype string
}

type wth struct {
	Enable   bool
	Factory  int
	Interval int
	Subinter int
	Decay    float32
}

type database struct {
	Driver string
	Master string
	Slave1 string
	Slave2 string
}

// 所有配置
type configure struct {
	Caiyun       caiyun
	Xiangji      xiangji
	Wth          wth
	Database     database
	Messagequeue messagequeue
}

func init() {
	// 将时区设置为东八区
	time.Local = time.FixedZone("UTC8", 8*3600)
	// 读取配置文件
	m := multiconfig.NewWithPath("config.toml")
	// 解析
	err := m.Load(&conf)
	if err != nil {
		log.WithFields(log.Fields{"product": "凉山电力", "program": "weather", "moudle": "config"}).Panicln("解析数据库配置失败")
	}
	// 赋值
	Caiyun = &conf.Caiyun
	Xiangji = &conf.Xiangji
	Wth = &conf.Wth
	Database = &conf.Database
	Messageque = &conf.Messagequeue
}
